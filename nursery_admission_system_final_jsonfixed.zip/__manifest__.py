{
    'name': 'Nursery Admission System_high',
    'version': '1.0',
    'summary': 'Manage nursery admissions with email notifications',
    'category': 'Education',
    'depends': ['base', 'mail', 'contacts'],
    'data': [
        'views/admission_views.xml',

        'security/ir.model.access.csv',
    ],
    'installable': True,
    'application': True,
}
