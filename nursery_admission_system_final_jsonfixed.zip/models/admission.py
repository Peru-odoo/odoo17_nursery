# -*- coding: utf-8 -*-
from odoo import api, fields, models
from odoo.exceptions import UserError


class NurseryAdmission(models.Model):
    _name = "nursery.admission"
    _inherit = ["mail.thread", "mail.activity.mixin"]  # chatter + activity
    _description = "Nursery Admission"

    # ---------------------------------------------------------------------
    # FIELDS
    # ---------------------------------------------------------------------
    child_name = fields.Char(string="Child Name", required=True, tracking=True)
    birth_date = fields.Date(string="Birth Date")
    gender = fields.Selection(
        [("male", "Male"), ("female", "Female")],
        string="Gender",
    )
    application_date = fields.Date(
        string="Application Date", default=fields.Date.context_today
    )
    status = fields.Selection(
        [
            ("draft", "Draft"),
            ("submitted", "Submitted"),
            ("accepted", "Accepted"),
            ("rejected", "Rejected"),
        ],
        default="draft",
        string="Status",
        tracking=True,
    )
    parent_id = fields.Many2one(
        "res.partner",
        string="Parent",
        required=True,
        tracking=True,
        domain="[('is_company', '=', False), ('email', '!=', False)]",
    )

    # ---------------------------------------------------------------------
    # STATE TRANSITIONS
    # ---------------------------------------------------------------------
    def _ensure_submitted(self):
        if any(rec.status != "submitted" for rec in self):
            raise UserError("Action allowed only on records in *Submitted* state.")

    def action_submit(self):
        """Optional button to move Draft → Submitted."""
        for rec in self.filtered(lambda r: r.status == "draft"):
            rec.status = "submitted"
        return True

    def action_accept(self):
        self._ensure_submitted()
        for rec in self:
            rec.status = "accepted"
            rec._send_template("nursery_admission_approved_template")

    def action_reject(self):
        self._ensure_submitted()
        for rec in self:
            rec.status = "rejected"
            rec._send_template("nursery_admission_rejected_template")

    # ---------------------------------------------------------------------
    # HELPERS
    # ---------------------------------------------------------------------
    def _send_template(self, xmlid):
        """Send e-mail and log to chatter if template exists & parent has email."""
        self.ensure_one()
        if not self.parent_id or not self.parent_id.email:
            return False  # nothing to send

        template = self.env.ref(xmlid, raise_if_not_found=False)
        if template:
            #  post in chatter AND deliver e-mail
            template.send_mail(self.id, force_send=True, email_values=None)
            self.message_post_with_view(
                "mail.message_notification",
                subtype_id=self.env.ref("mail.mt_comment").id,
                values={
                    "message": f"E-mail sent using template {template.name}",
                },
            )
        else:
            # template missing – still accept/reject but warn in chatter
            self.message_post(
                body=f"WARNING: Template '{xmlid}' not found. "
                     "No e-mail was sent.",
                subtype_xmlid="mail.mt_comment",
            )
        return True


